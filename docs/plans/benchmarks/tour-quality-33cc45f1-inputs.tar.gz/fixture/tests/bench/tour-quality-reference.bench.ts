import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { setTimeout as delay } from "node:timers/promises";
import { errors, expect, test, type CDPSession, type Page } from "@playwright/test";
import { MOBILE_PROFILE, newMobilePage, verifySoftwareWebGLRenderer } from "./tour-mobile-profile";

const ROOM = "pv-living";
const VILLA = "/rooms/pool-villa";
const MOBILE_IMAGE = "/tour/panoramas/v1/pool-villa-living-2048.webp";
const FULL_IMAGE = "/pool-villa-living.webp";
const QUIET_MS = 250;
const POSE_TOLERANCE_DEG = 0.2;
const CACHE_HIT = "first_panorama_cache_hit";
const SWEEP = { fromDeg: 10, throughDeg: 14, toDeg: 18, moves: 8, intervalMs: 60 };
const CENTER = { x: 190, y: 390 };

interface Draw {
  at: number;
  sequence: number;
  yaw: number;
  pitch: number;
  room: string;
}

interface Surface {
  gl: WebGL2RenderingContext;
  pitch: number;
  losses: number;
  restores: number;
  extension?: WEBGL_lose_context;
}

type QualityWindow = Window & {
  __tourBench: { mark(name: string): void; frame(yaw: number, room: string): void };
  __quality: {
    last: Draw | null;
    surface?: Surface;
    marks: { name: string; at: number }[];
    sweepFrames: Draw[] | null;
    trusted: { type: string; x: number; y: number; at: number; stamped: number }[];
  };
};

function installObservation() {
  const w = window as unknown as QualityWindow;
  const state: QualityWindow["__quality"] = { last: null, marks: [], sweepFrames: null, trusted: [] };
  w.__quality = state;
  const surfaces = new WeakMap<WebGL2RenderingContext, Surface>();
  const modelViews = new WeakSet<WebGLUniformLocation>();
  const prototype = WebGL2RenderingContext.prototype;
  const location = prototype.getUniformLocation;
  prototype.getUniformLocation = function (this: WebGL2RenderingContext, program, name) {
    const uniform = location.call(this, program, name);
    if (uniform && name === "modelViewMatrix") modelViews.add(uniform);
    return uniform;
  };
  const upload = prototype.uniformMatrix4fv;
  prototype.uniformMatrix4fv = function (this: WebGL2RenderingContext, ...args: Parameters<typeof upload>) {
    const [uniform, , values, offset = 0] = args;
    if (uniform && modelViews.has(uniform)) {
      let surface = surfaces.get(this);
      if (!surface) {
        const entry: Surface = { gl: this, pitch: 0, losses: 0, restores: 0 };
        this.canvas.addEventListener("webglcontextlost", () => { entry.losses++; });
        this.canvas.addEventListener("webglcontextrestored", () => { entry.restores++; });
        surfaces.set(this, entry);
        surface = entry;
      }
      // The sphere's fixed model rotation is exclusively around Y, preserving model/world up.
      // Row Z, column Y in its model-view rotation gives the backward viewing direction's Y.
      surface.pitch = Math.asin(Math.max(-1, Math.min(1, -values[offset + 6])));
      state.surface = surface;
    }
    return upload.apply(this, args);
  };
  w.__tourBench = {
    mark(name) { state.marks.push({ name, at: performance.now() }); },
    frame(yaw, room) {
      if (!state.surface?.gl.canvas) return;
      state.last = {
        yaw, room, pitch: state.surface.pitch, at: performance.now(),
        sequence: (state.last?.sequence ?? 0) + 1,
      };
      state.sweepFrames?.push(state.last);
    },
  };
  for (const type of ["pointerdown", "pointermove", "pointerup"]) {
    document.addEventListener(type, (event) => {
      if (event instanceof PointerEvent && event.isTrusted && event.pointerType === "touch" &&
          event.target instanceof HTMLCanvasElement) {
        state.trusted.push({ type, x: event.clientX, y: event.clientY, at: performance.now(), stamped: event.timeStamp });
      }
    }, { capture: true, passive: true });
  }
}

async function readPose(page: Page) {
  return page.evaluate(() => {
    const state = (window as unknown as QualityWindow).__quality;
    const surface = state.surface;
    const canvas = surface?.gl.canvas;
    if (!state.last || !surface || !(canvas instanceof HTMLCanvasElement) || !canvas.isConnected) {
      throw Error("Missing attached observed WebGL panorama");
    }
    const bounds = canvas.getBoundingClientRect();
    return {
      ...state.last,
      canvas: {
        css: { x: bounds.x, y: bounds.y, width: bounds.width, height: bounds.height },
        backing: { width: canvas.width, height: canvas.height },
        buffer: { width: surface.gl.drawingBufferWidth, height: surface.gl.drawingBufferHeight },
      },
      marks: state.marks,
      losses: surface.losses,
      restores: surface.restores,
      context: surface.gl.getContextAttributes(),
    };
  });
}

async function settled(page: Page) {
  await page.waitForFunction(({ room, center, quiet }) => {
    const viewer = document.querySelector('[data-testid="tour-viewer"]');
    const state = (window as unknown as QualityWindow).__quality;
    const canvas = state.surface?.gl.canvas;
    return viewer?.getAttribute("data-requested-room") === room &&
      viewer.getAttribute("data-shown-room") === room && viewer.getAttribute("data-live") === "confirmed" &&
      viewer.getAttribute("data-scene-status") === "ready" && viewer.getAttribute("aria-busy") === "false" &&
      canvas instanceof HTMLCanvasElement && viewer.contains(canvas) && canvas === document.elementFromPoint(center.x, center.y) &&
      canvas.checkVisibility({ opacityProperty: true, visibilityProperty: true }) &&
      !state.surface?.gl.isContextLost() && state.last?.room === room && performance.now() - state.last.at >= quiet &&
      !viewer.getAnimations({ subtree: true }).some((animation) =>
        animation.playState === "running" && Number.isFinite(animation.effect?.getComputedTiming().endTime),
      );
  }, { room: ROOM, center: CENTER, quiet: QUIET_MS }, { timeout: 60_000, polling: "raf" });
  return readPose(page);
}

async function touch(cdp: CDPSession, dx: number, dy: number) {
  await cdp.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [CENTER] });
  for (let part = 1; part <= 4; part++) {
    await cdp.send("Input.dispatchTouchEvent", {
      type: "touchMove",
      touchPoints: [{ x: CENTER.x + dx * part / 4, y: CENTER.y + dy * part / 4 }],
    });
  }
  await cdp.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
}

const rad = Math.PI / 180;
const angularDelta = (a: number, b: number) => Math.atan2(Math.sin(a - b), Math.cos(a - b));

async function steer(page: Page, cdp: CDPSession, initial: Draw, yawDeg: number, pitchDeg: number) {
  const yaw = initial.yaw + yawDeg * rad;
  const pitch = initial.pitch + pitchDeg * rad;
  let pose = await settled(page);
  // Calibrate with trusted gesture feedback while keeping every move well inside the canvas.
  let gainX = 2 * Math.PI * 0.45 / pose.canvas.css.height;
  let gainY = gainX;
  let moves = 0;
  for (; moves < 8; moves++) {
    const yawError = angularDelta(yaw, pose.yaw);
    const pitchError = pitch - pose.pitch;
    if (Math.max(Math.abs(yawError), Math.abs(pitchError)) <= POSE_TOLERANCE_DEG * rad) break;
    const clamp = (px: number) => Math.max(-135, Math.min(135, px));
    const dx = clamp(yawError / gainX);
    const dy = clamp(pitchError / gainY);
    const previous = pose;
    await touch(cdp, dx, dy);
    try {
      await page.waitForFunction((seq) => (window as unknown as QualityWindow).__quality.last?.sequence !== seq,
        previous.sequence, { timeout: 3_000, polling: "raf" });
    } catch (error) {
      if (!(error instanceof errors.TimeoutError)) throw error;
      // A real touch can be ignored during viewport/compositor work. Retry the same measured
      // correction within the bounded loop and keep the final angle requirement unchanged.
      continue;
    }
    pose = await settled(page);
    if (Math.abs(dx) > 3) gainX = angularDelta(pose.yaw, previous.yaw) / dx || gainX;
    if (Math.abs(dy) > 3) gainY = (pose.pitch - previous.pitch) / dy || gainY;
  }
  expect(Math.abs(angularDelta(yaw, pose.yaw))).toBeLessThanOrEqual(POSE_TOLERANCE_DEG * rad);
  expect(Math.abs(pitch - pose.pitch)).toBeLessThanOrEqual(POSE_TOLERANCE_DEG * rad);
  expect(moves).toBeGreaterThan(0);
  return { yawDeg, pitchDeg, moves, gainY };
}

async function sweepMipBoundary(page: Page, cdp: CDPSession, initial: Draw) {
  const { gainY } = await steer(page, cdp, initial, 0, SWEEP.fromDeg);
  const before = await settled(page);
  const startIndex = await page.evaluate(() => {
    const state = (window as unknown as QualityWindow).__quality;
    state.sweepFrames = [];
    return state.trusted.length;
  });
  const dy = (((SWEEP.toDeg * rad) + initial.pitch) - before.pitch) / gainY;
  expect(Math.abs(dy)).toBeLessThan(100);
  await cdp.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [CENTER] });
  for (let part = 1; part <= SWEEP.moves; part++) {
    await delay(SWEEP.intervalMs);
    await cdp.send("Input.dispatchTouchEvent", {
      type: "touchMove",
      touchPoints: [{ x: CENTER.x, y: CENTER.y + dy * part / SWEEP.moves }],
    });
  }
  await cdp.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
  const after = await settled(page);
  const observations = await page.evaluate((index) => {
    const state = (window as unknown as QualityWindow).__quality;
    const frames = state.sweepFrames ?? [];
    state.sweepFrames = null;
    return { frames, inputs: state.trusted.slice(index) };
  }, startIndex);
  const initialPitch = initial.pitch;
  const pitch = (value: number) => (value - initialPitch) / rad;
  const crossing = observations.frames.findIndex((frame) => pitch(frame.pitch) >= SWEEP.throughDeg);
  expect(crossing).toBeGreaterThan(0);
  expect(Math.abs(pitch(after.pitch) - SWEEP.toDeg)).toBeLessThanOrEqual(1);
  const moves = observations.inputs.filter(({ type }) => type === "pointermove");
  expect(moves.length).toBeGreaterThanOrEqual(SWEEP.moves - 1);
  const frames = observations.frames.map((frame) => ({ ...frame, relativePitchDeg: pitch(frame.pitch) }));
  const frameGapsMs = frames.slice(1).map((frame, index) => frame.at - frames[index].at);
  const moveDeliveryMs = moves.map((event) => event.at - event.stamped);
  return {
    protocol: SWEEP, fromDeg: pitch(before.pitch), toDeg: pitch(after.pitch), nativeInputs: observations.inputs, frames,
    crossingFrame: frames[crossing], crossingGapMs: frameGapsMs[crossing - 1], frameGapsMs, moveDeliveryMs,
  };
}

function pngSize(png: Buffer) {
  return { width: png.readUInt32BE(16), height: png.readUInt32BE(20) };
}

async function capture(page: Page, directory: string, name: string, target?: { yawDeg: number; pitchDeg: number; moves: number }) {
  const pose = await settled(page);
  const png = await page.screenshot({ scale: "device" });
  const after = await readPose(page);
  expect(Math.abs(angularDelta(after.yaw, pose.yaw))).toBeLessThanOrEqual(0.02 * rad);
  expect(Math.abs(after.pitch - pose.pitch)).toBeLessThanOrEqual(0.02 * rad);
  expect(after.losses).toBe(pose.losses);
  expect(after.restores).toBe(pose.restores);
  expect(after.canvas).toEqual(pose.canvas);
  const size = pngSize(png);
  expect(size).toEqual({ width: MOBILE_PROFILE.width * MOBILE_PROFILE.dpr, height: MOBILE_PROFILE.height * MOBILE_PROFILE.dpr });
  const file = name + ".png";
  writeFileSync(join(directory, file), png, { flag: "wx", mode: 0o600 });
  return { file, size, pose, target, captureDrawCount: after.sequence - pose.sequence, sha256: createHash("sha256").update(png).digest("hex") };
}

async function recover(page: Page) {
  const before = await settled(page);
  await page.evaluate(() => {
    const surface = (window as unknown as QualityWindow).__quality.surface!;
    surface.extension = surface.gl.getExtension("WEBGL_lose_context") ?? undefined;
    if (!surface.extension) throw Error("WEBGL_lose_context is required");
    surface.extension.loseContext();
  });
  await page.waitForFunction((n) => (window as unknown as QualityWindow).__quality.surface!.losses > n, before.losses);
  await page.evaluate(() => (window as unknown as QualityWindow).__quality.surface!.extension!.restoreContext());
  await page.waitForFunction(({ restores, sequence }) => {
    const { surface, last } = (window as unknown as QualityWindow).__quality;
    return !!last && !!surface && surface.restores > restores && last.sequence > sequence;
  }, before);
  const after = await settled(page);
  expect(Math.abs(angularDelta(after.yaw, before.yaw))).toBeLessThanOrEqual(POSE_TOLERANCE_DEG * rad);
  expect(Math.abs(after.pitch - before.pitch)).toBeLessThanOrEqual(POSE_TOLERANCE_DEG * rad);
}

test("capture fixed mobile panorama quality references", async ({ browser }) => {
  const directory = process.env.BENCH_TOUR_QUALITY_OUT;
  const revision = process.env.BENCH_TOUR_QUALITY_SOURCE;
  test.skip(!directory, "Set a new private reference output directory.");
  if (!directory) return;
  if (!revision || !/^[a-f0-9]{40}$/.test(revision)) throw Error("Provide the built application source SHA");
  const base = new URL(process.env.BENCH_BASE_URL ?? process.env.E2E_BASE_URL!);
  expect(["localhost", "127.0.0.1"]).toContain(base.hostname);
  mkdirSync(directory, { mode: 0o700 });
  const renderer = await verifySoftwareWebGLRenderer(browser);
  const captures: Awaited<ReturnType<typeof capture>>[] = [];
  const direct = await newMobilePage(browser, true, installObservation);
  const requests: string[] = [];
  const trusted: QualityWindow["__quality"]["trusted"] = [];
  let mipSweep: Awaited<ReturnType<typeof sweepMipBoundary>> | undefined;
  direct.page.on("request", (request) => {
    const pathname = new URL(request.url()).pathname;
    if (pathname === MOBILE_IMAGE || pathname === FULL_IMAGE) requests.push(pathname);
  });
  try {
    await direct.page.goto(VILLA + "?tour=1");
    const first = await capture(direct.page, directory, "direct-initial");
    captures.push(first);
    expect(requests).toEqual([MOBILE_IMAGE]);
    for (const [name, yaw, pitch] of [["right", 40, 0], ["upper-left", -25, 35], ["lower-right", 20, -35]] as const) {
      const target = await steer(direct.page, direct.cdp, first.pose, yaw, pitch);
      captures.push(await capture(direct.page, directory, name, target));
    }
    expect(requests).toEqual([MOBILE_IMAGE]);
    mipSweep = await sweepMipBoundary(direct.page, direct.cdp, first.pose);
    await steer(direct.page, direct.cdp, first.pose, 20, -35);
    trusted.push(...await direct.page.evaluate(() => (window as unknown as QualityWindow).__quality.trusted));
    expect(trusted.some(({ type, y }) => type === "pointermove" && Math.abs(y - CENTER.y) > 45)).toBe(true);
    expect(trusted.some(({ type, x }) => type === "pointermove" && Math.abs(x - CENTER.x) > 45)).toBe(true);
    await recover(direct.page);
    captures.push(await capture(direct.page, directory, "recovered-lower-right"));
    const viewer = direct.page.getByTestId("tour-viewer");
    const before = await readPose(direct.page);
    await viewer.getByRole("button", { name: "Show full detail" }).tap();
    await expect(viewer.getByRole("button", { name: "Full detail shown" })).toBeVisible({ timeout: 40_000 });
    await direct.page.waitForFunction((seq) => (window as unknown as QualityWindow).__quality.last!.sequence > seq, before.sequence);
    captures.push(await capture(direct.page, directory, "full-detail-lower-right"));
    expect(requests).toEqual([MOBILE_IMAGE, FULL_IMAGE]);
  } finally {
    await direct.context.close();
  }

  const warm = await newMobilePage(browser, false, installObservation);
  const warmRequests: string[] = [];
  warm.page.on("request", (request) => {
    const pathname = new URL(request.url()).pathname;
    if (pathname === MOBILE_IMAGE || pathname === FULL_IMAGE) warmRequests.push(pathname);
  });
  try {
    await warm.page.goto(VILLA);
    const explore = warm.page.getByRole("button", { name: /Explore (in )?360/i }).first();
    const viewer = warm.page.getByTestId("tour-viewer");
    await explore.tap();
    captures.push(await capture(warm.page, directory, "first-open-initial"));
    await viewer.getByRole("button", { name: "Close" }).first().tap();
    await viewer.waitFor({ state: "detached" });
    await warm.page.evaluate(() => { (window as unknown as QualityWindow).__quality.marks = []; });
    await explore.tap();
    const warmInitial = await capture(warm.page, directory, "warm-initial");
    captures.push(warmInitial);
    if (process.env.BENCH_TOUR_QUALITY_REQUIRE_CPU_HIT === "1") {
      expect(warmInitial.pose.marks.some(({ name, at }) => name === CACHE_HIT && at <= warmInitial.pose.at)).toBe(true);
    }
    await recover(warm.page);
    captures.push(await capture(warm.page, directory, "recovered-warm-initial"));
    expect(warmRequests[0]).toBe(MOBILE_IMAGE);
    expect(warmRequests.every((pathname) => pathname === MOBILE_IMAGE)).toBe(true);
  } finally {
    await warm.context.close();
  }

  writeFileSync(join(directory, "manifest.json"), JSON.stringify({
    schema: "tour-quality-reference/v1", revision,
    fixtureRevision: execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8" }).trim(),
    fixtureSha256: createHash("sha256").update(readFileSync(fileURLToPath(import.meta.url))).digest("hex"),
    room: ROOM, mobileImage: MOBILE_IMAGE, fullImage: FULL_IMAGE, browser: browser.version(), renderer,
    profile: MOBILE_PROFILE, quietMs: QUIET_MS, poseToleranceDeg: POSE_TOLERANCE_DEG, requests, warmRequests, trusted, captures, mipSweep,
    requireCpuHit: process.env.BENCH_TOUR_QUALITY_REQUIRE_CPU_HIT === "1",
    builtMobileSha256: process.env.BENCH_TOUR_QUALITY_ASSET_SHA256,
  }, null, 2) + "\n", { flag: "wx", mode: 0o600 });
});
