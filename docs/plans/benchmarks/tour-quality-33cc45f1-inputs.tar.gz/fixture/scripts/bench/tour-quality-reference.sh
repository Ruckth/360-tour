#!/bin/bash
set -euo pipefail
umask 077
export VITEST_MAX_WORKERS=2
app=${1:?Isolated application worktree}
revision=${2:?Exact built SHA}
out=${3:?New absolute output directory}
case "$out" in /*) ;; *) exit 2;; esac
lab=$(cd -P "$(dirname "$0")/../.." && pwd)
cd -P "$app"
test "$(git rev-parse HEAD)" = "$revision"
test "$(git status --porcelain --untracked-files=no)" = ""
mkdir -m 700 "$out"
BENCH_START_WIRE_GZIP=1 node scripts/heavy.mjs node scripts/local-integration.mjs --start -- bash -c '
  set -euo pipefail
  lab=$1
  out=$2
  export BENCH_TOUR_QUALITY_SOURCE=$3
  export BENCH_TOUR_QUALITY_REQUIRE_CPU_HIT=$4
  export BENCH_TOUR_QUALITY_OUT="$out/reference"
  export BENCH_TOUR_QUALITY_ASSET_SHA256=$(shasum -a 256 .output/public/tour/panoramas/v1/pool-villa-living-2048.webp | cut -c1-64)
  cd -P "$lab"
  bun run bench:browser "tests/bench/tour-quality-reference\.bench\.ts$"
' tour-quality-reference "$lab" "$out" "$revision" "${BENCH_TOUR_QUALITY_REQUIRE_CPU_HIT:-0}" > "$out/harness.log" 2>&1
