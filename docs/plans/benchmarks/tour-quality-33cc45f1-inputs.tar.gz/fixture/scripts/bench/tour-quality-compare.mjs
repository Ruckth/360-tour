import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import sharp from "sharp";

const controlRevision = "e9af90fa";
const names = ["direct-initial", "right", "upper-left", "lower-right", "recovered-lower-right", "full-detail-lower-right", "first-open-initial", "warm-initial", "recovered-warm-initial"];
const [control, candidate] = process.argv.slice(2);
if (!control || !candidate) throw Error("Pass the two reference directories containing manifests and PNGs");
const manifest = (directory) => JSON.parse(readFileSync(join(directory, "manifest.json"), "utf8"));
const a = manifest(control), b = manifest(candidate);
assert(a.revision.startsWith(controlRevision), "The control must be the unmodified quality baseline");
for (const field of ["schema", "fixtureSha256", "room", "browser", "renderer", "profile", "builtMobileSha256"]) {
  assert(a[field] != null, `Missing reference field ${field}`);
  assert.deepEqual(a[field], b[field], `Different ${field}`);
}
const angleDistance = (x, y) => Math.abs(Math.atan2(Math.sin(x - y), Math.cos(x - y))) * 180 / Math.PI;
const outcomes = [];
for (const [index, name] of names.entries()) {
  const left = a.captures[index], right = b.captures[index];
  assert.equal(left.file, name + ".png");
  assert.equal(left.file, right.file);
  assert.deepEqual(left.size, right.size, name);
  for (const dimension of ["x", "y", "width", "height"]) {
    assert(Math.abs(left.pose.canvas.css[dimension] - right.pose.canvas.css[dimension]) <= 0.5, name + " CSS bounds");
  }
  const yawDifferenceDeg = angleDistance(left.pose.yaw, right.pose.yaw);
  const pitchDifferenceDeg = angleDistance(left.pose.pitch, right.pose.pitch);
  assert(Math.max(yawDifferenceDeg, pitchDifferenceDeg) <= a.poseToleranceDeg + b.poseToleranceDeg, name + " pose");
  const pixels = await Promise.all([[control, left], [candidate, right]].map(async ([directory, record]) => {
    const png = readFileSync(join(directory, record.file));
    assert.equal(createHash("sha256").update(png).digest("hex"), record.sha256);
    const { data, info } = await sharp(png).toColourspace("srgb").removeAlpha().raw().toBuffer({ resolveWithObject: true });
    assert.equal(info.channels, 3);
    assert.equal(info.width, record.size.width);
    assert.equal(info.height, record.size.height);
    return data;
  }));
  let absolute = 0, aboveSix = 0;
  for (let i = 0; i < pixels[0].length; i += 3) {
    const red = Math.abs(pixels[0][i] - pixels[1][i]);
    const green = Math.abs(pixels[0][i + 1] - pixels[1][i + 1]);
    const blue = Math.abs(pixels[0][i + 2] - pixels[1][i + 2]);
    absolute += red + green + blue;
    if (Math.max(red, green, blue) > 6) aboveSix++;
  }
  outcomes.push({
    name, yawDifferenceDeg, pitchDifferenceDeg,
    controlCanvas: left.pose.canvas, candidateCanvas: right.pose.canvas,
    meanAbsoluteChannelDifference: absolute / pixels[0].length,
    pixelFractionAboveSix: aboveSix / (pixels[0].length / 3),
  });
}
const warmHit = (record) => record.captures.find(({ file }) => file === "warm-initial.png").pose.marks
  .some(({ name }) => name === "first_panorama_cache_hit");
if (b.requireCpuHit) assert(warmHit(b), "Candidate warm open must demonstrate its CPU cache hit");
assert.deepEqual(a.mipSweep.protocol, b.mipSweep.protocol, "Use the same pitch sweep on both arms");
const sweep = (record) => ({
  fromDeg: record.mipSweep.fromDeg, toDeg: record.mipSweep.toDeg,
  crossingGapMs: record.mipSweep.crossingGapMs, maxFrameGapMs: Math.max(...record.mipSweep.frameGapsMs),
  maxNativeMoveDeliveryMs: Math.max(...record.mipSweep.moveDeliveryMs),
});
console.log(JSON.stringify({
  control: a.revision, candidate: b.revision, outcomes,
  warmCacheHit: { control: warmHit(a), candidate: warmHit(b) },
  mipSweep: { protocol: a.mipSweep.protocol, control: sweep(a), candidate: sweep(b) },
}, null, 2));
